/// <reference types="astro/client" />
