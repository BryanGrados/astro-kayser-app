import { Text } from "@mantine/core";
export default function Texts({ content, ...props }) {
	return <Text {...props}>{content}</Text>;
}
